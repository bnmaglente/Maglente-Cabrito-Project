from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime, timedelta
import re

app = Flask(__name__)
app.secret_key = "takda_secret"

# ------------------ DATA ------------------
users = {
    "04-2024-022": {
        "name": "Admin",
        "role": "Admin",
        "borrowed_books": [],
        "section": "",
        "reservations": []
    }
}

borrowed_books = {}
auditorium_reservations = []
announcements = []

ADMIN_ID = "04-2024-022"

# ------------------ HOME ------------------
@app.route("/")
def index():
    return render_template("index.html")

# ------------------ LOGIN ------------------
@app.route("/login", methods=["GET", "POST"])
def login_form():
    if request.method == "POST":
        raw_id = request.form.get("id", "").strip()

        if not raw_id:
            flash("Enter ID")
            return redirect(url_for("login_form"))

        user_id = raw_id.replace(" ", "-")

        if user_id in users:
            session["user_id"] = user_id
            flash(f"Welcome {users[user_id]['name']}!")
            return redirect(url_for("menu"))

        flash("User not found. Please register first.")
        return redirect(url_for("login_form"))

    return render_template("form.html", title="Login",
                           action=url_for("login_form"),
                           fields={"Enter ID": "id"})

# ------------------ REGISTER ------------------
@app.route("/register", methods=["GET", "POST"])
def register_form():
    if request.method == "POST":
        raw_id = request.form.get("id", "").strip()
        name = request.form.get("name", "").strip()
        role = request.form.get("role", "").strip()
        section = request.form.get("section", "").strip()

        if not raw_id or not name or not role:
            flash("All fields are required.")
            return redirect(url_for("register_form"))

        if not re.fullmatch(r"[A-Za-z ]+", name):
            flash("Name must contain letters only.")
            return redirect(url_for("register_form"))

        if not re.fullmatch(r"[A-Za-z ]+", role):
            flash("Role must contain letters only.")
            return redirect(url_for("register_form"))

        if section and not re.fullmatch(r"[A-Za-z ]+", section):
            flash("Section must contain letters only.")
            return redirect(url_for("register_form"))

        user_id = raw_id.replace(" ", "-")

        if user_id in users:
            flash("User already exists.")
            return redirect(url_for("register_form"))

        if role.lower() == "admin":
            flash("Cannot register as admin.")
            return redirect(url_for("register_form"))

        users[user_id] = {
            "name": name,
            "role": role.capitalize(),
            "section": section,
            "borrowed_books": [],
            "reservations": []
        }

        flash("Registration successful!")
        return redirect(url_for("login_form"))

    return render_template("form.html", title="Register",
                           action=url_for("register_form"),
                           fields={
                               "Enter ID": "id",
                               "Name": "name",
                               "Role": "role",
                               "Section": "section"
                           })

# ------------------ MENU ------------------
@app.route("/menu")
def menu():
    user_id = session.get("user_id")

    if not user_id or user_id not in users:
        session.pop("user_id", None)
        return redirect(url_for("index"))

    role = users[user_id]["role"]
    return render_template("menu.html", role=role)

# ------------------ LOGOUT ------------------
@app.route("/logout")
def logout():
    session.pop("user_id", None)
    flash("Logged out successfully!")
    return redirect(url_for("index"))

# ------------------ ANNOUNCEMENTS ------------------
@app.route("/announcements")
def view_announcements():
    return render_template("list.html",
                           title="Announcements",
                           items=announcements)

# ------------------ BORROW ------------------
@app.route("/borrow", methods=["GET", "POST"])
def borrow_book():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("index"))

    if request.method == "POST":
        book = request.form.get("book", "").strip()

        if not book:
            flash("Enter book title.")
            return redirect(url_for("borrow_book"))

        if book in borrowed_books:
            flash("Book already borrowed.")
            return redirect(url_for("borrow_book"))

        borrowed_books[book] = user_id

        users[user_id]["borrowed_books"].append({
            "book": book,
            "borrow_time": datetime.now(),
            "return_time": datetime.now() + timedelta(days=1)
        })

        flash("Book borrowed successfully!")
        return redirect(url_for("menu"))

    return render_template("form.html", title="Borrow Book",
                           action=url_for("borrow_book"),
                           fields={"Book Title": "book"})

# ------------------ RESERVE ------------------
@app.route("/reserve", methods=["GET", "POST"])
def reserve():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("index"))

    if request.method == "POST":
        date = request.form.get("date", "").strip()
        start = request.form.get("start_time", "").strip()
        end = request.form.get("end_time", "").strip()
        purpose = request.form.get("purpose", "").strip()

        auditorium_reservations.append({
            "student_id": user_id,
            "date": date,
            "start_time": start,
            "end_time": end,
            "purpose": purpose,
            "status": "Pending"
        })

        flash("Reservation submitted.")
        return redirect(url_for("menu"))

    return render_template("form.html", title="Reserve Auditorium",
                           action=url_for("reserve"),
                           fields={
                               "Date": "date",
                               "Start Time": "start_time",
                               "End Time": "end_time",
                               "Purpose": "purpose"
                           })

# ------------------ MY BOOKS ------------------
@app.route("/mybooks")
def my_books():
    user_id = session.get("user_id")

    if not user_id or user_id not in users:
        return redirect(url_for("index"))

    books = [
        f"{b['book']} (return by {b['return_time'].strftime('%Y-%m-%d %H:%M')})"
        for b in users[user_id]["borrowed_books"]
    ]

    if not books:
        books = ["No borrowed books"]

    return render_template("list.html",
                           title="My Borrowed Books",
                           items=books)

# ------------------ MY RESERVATIONS ------------------
@app.route("/myreservations")
def my_reservations():
    user_id = session.get("user_id")

    if not user_id or user_id not in users:
        return redirect(url_for("index"))

    res_list = [
        f"{r['date']} {r['start_time']}-{r['end_time']} | {r['purpose']} | {r['status']}"
        for r in auditorium_reservations
        if r["student_id"] == user_id
    ]

    if not res_list:
        res_list = ["No reservations"]

    return render_template("list.html",
                           title="My Reservations",
                           items=res_list)

# ------------------ ADMIN ANNOUNCE ------------------
@app.route("/admin/announce", methods=["GET", "POST"])
def admin_announce():
    user_id = session.get("user_id")

    if user_id != ADMIN_ID:
        flash("Admin only!")
        return redirect(url_for("index"))

    if request.method == "POST":
        text = request.form.get("announcement", "").strip()

        if text:
            announcements.append(text)
            flash("Announcement added!")
            return redirect(url_for("menu"))
        else:
            flash("Enter announcement.")

    return render_template("form.html",
                           title="Make Announcement",
                           action=url_for("admin_announce"),
                           fields={"Announcement Text": "announcement"})

# ------------------ ADMIN REMINDERS ------------------
@app.route("/admin/reminders")
def admin_reminders():
    user_id = session.get("user_id")

    if user_id != ADMIN_ID:
        flash("Admin only!")
        return redirect(url_for("index"))

    items = []
    now = datetime.now()

    for uid, user in users.items():
        if uid == ADMIN_ID:
            continue

        for b in user["borrowed_books"]:
            remaining = b["return_time"] - now
            status = "OVERDUE" if remaining.total_seconds() < 0 else "Due soon"
            items.append(f"{user['name']} ({uid}): {b['book']} - {status}")

    if not items:
        items = ["No reminders"]

    return render_template("list.html",
                           title="All Users Reminders",
                           items=items)

# ------------------ ADMIN APPROVALS ------------------
@app.route("/admin/approvals", methods=["GET", "POST"])
def admin_approvals():
    user_id = session.get("user_id")

    if user_id != ADMIN_ID:
        flash("Admin only!")
        return redirect(url_for("index"))

    if request.method == "POST":
        try:
            idx = int(request.form.get("idx"))
            action = request.form.get("action")

            if 0 <= idx < len(auditorium_reservations):
                if action == "approve":
                    auditorium_reservations[idx]["status"] = "Approved"
                elif action == "reject":
                    auditorium_reservations[idx]["status"] = "Rejected"
        except:
            pass

        return redirect(url_for("admin_approvals"))

    pending = [r for r in auditorium_reservations if r["status"] == "Pending"]

    return render_template("admin_approvals.html",
                           reservations=pending,
                           users=users)

# ------------------ RUN ------------------
if __name__ == "__main__":
    app.run(debug=True)